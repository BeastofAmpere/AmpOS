echo 
echo "Gzip"
echo
sleep 1

cd $LFS/sources
tar -xf gzip-*.tar.xz
cd gzip-1.12

./configure --prefix=/usr --host=$LFS_TGT

make

make DESTDIR=$LFS install

mv -v $LFS/usr/bin/gzip $LFS/bin

cd $LFS/sources
rm -rf gzip-1.12