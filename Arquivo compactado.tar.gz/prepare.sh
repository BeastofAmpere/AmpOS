##1- Crie 3 particoes para seu destino usando Gparted

##2- Tenha conexão com a internet

##3- Valido para sda, mude para outro caso necessário

#Definindo LFS
#export LFS=/mnt/lfs
#echo "LFS: ${LFS:?}"

#Montando
#mount -v -t ext4 /dev/sda2 $LFS
#/sbin/swapon -v /dev/sda3

#Criando diretorios
#mkdir -pv $LFS
#mkdir -v $LFS/sources

#chmod -v a+wt $LFS/sources
cd $LFS/sources

#Software download
wget https://linuxfromscratch.org/lfs/view/stable-systemd/wget-list-systemd
wget https://linuxfromscratch.org/lfs/view/stable-systemd/md5sums

wget --input-file=wget-list-systemd --continue --directory-prefix=$LFS/sources

md5sum -c md5sums

mkdir -pv $LFS/{etc,var} $LFS/usr/{bin,lib,sbin}

for i in bin lib sbin; do
  ln -sv usr/$i $LFS/$i
done

case $(uname -m) in
  x86_64) mkdir -pv $LFS/lib64 ;;
esac

mkdir -pv $LFS/tools

if ! test $(id -u lfs) ; then

groupadd lfs
useradd -s /bin/bash -g lfs -m -k /dev/null lfs
passwd lfs
chown -v lfs $LFS/{usr{,/*},lib,var,etc,bin,sbin,tools}
case $(uname -m) in
  x86_64) chown -v lfs $LFS/lib64 ;;
esac

dbhome=$(eval echo "~lfs")

cat > ~/.bash_profile << "EOF"
exec env -i HOME=$HOME TERM=$TERM PS1='\u:\w\$ ' /bin/bash
EOF

cat > ~/.bashrc << "EOF"
set +h
umask 022
LFS=/mnt/lfs
LC_ALL=POSIX
LFS_TGT=$(uname -m)-lfs-linux-gnu
PATH=/usr/bin
if [ ! -L /bin ]; then PATH=/bin:$PATH; fi
PATH=$LFS/tools/bin:$PATH
CONFIG_SITE=$LFS/usr/share/config.site
export LFS LC_ALL LFS_TGT PATH CONFIG_SITE
export MAKEFLAGS="-j$(nproc)"
EOF

fi
[ ! -e /etc/bash.bashrc ] || mv -v /etc/bash.bashrc /etc/bash.bashrc.NOUSE
source ~/.bash_profile
echo "READY!" #Enter the new user!