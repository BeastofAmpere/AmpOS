set -e

echo "LFS: ${LFS:?}"

if ! test $(whoami) == "lfs" ; then
    echo "Must run as lfs user!"
    exit -1
fi

echo "Creating build environment..."
cd $LFS/sources
sleep 1

#Compiling a Cross-Toolchain
#bash -e build_scripts/binutils-pass-1.sh binutils-*.tar.xz
bash -e build_scripts/gcc-pass-1.sh gcc-*.tar.xz
bash -e build_scripts/linux-headers.sh
bash -e build_scripts/glibc.sh
bash -e build_scripts/libstdcpp-pass-1.sh gcc-*.tar.xz

#Cross Compiling Temporary Tools
bash -e build_scripts/m4.sh m4-*.tar.xz
bash -e build_scripts/ncurses.sh ncurses-*.tar.gz
bash -e build_scripts/bash.sh bash-*.tar.gz
bash -e build_scripts/coreutils.sh coreutils-*.tar.xz
bash -e build_scripts/diffutils.sh diffutils-*.tar.xz
bash -e build_scripts/file.sh file-*.tar.gz
bash -e build_scripts/findutils.sh findutils-*.tar.xz
bash -e build_scripts/gawk.sh gawk-*.tar.xz
bash -e build_scripts/grep.sh grep-*.tar.xz
bash -e build_scripts/gzip.sh gzip-*.tar.xz
bash -e build_scripts/make.sh make-*.tar.gz
bash -e build_scripts/patch.sh patch-*.tar.xz
bash -e build_scripts/sed.sh sed-*.tar.xz
bash -e build_scripts/tar.sh tar-*.tar.xz
bash -e build_scripts/xz.sh xz-*.tar.xz
bash -e build_scripts/binutils-pass-2.sh binutils-*.tar.xz
bash -e build_scripts/gcc-pass-2.sh gcc-*.tar.xz

echo "DONE!" #Return to root!